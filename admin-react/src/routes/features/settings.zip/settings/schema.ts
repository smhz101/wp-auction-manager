// /features/settings/schema.ts
import { z } from 'zod'

export const CURRENCIES = ['EUR', 'GBP', 'USD'] as const
export const BID_STRATEGIES = ['fixed', 'tiered'] as const
export const PAYMENT_METHODS = ['bank', 'card', 'paypal'] as const
export const KYC_PROVIDERS = ['manual', 'persona', 'sumsub'] as const

//

export const WEBHOOK_EVENTS = [
  'bid.placed',
  'cart.abandoned',
  'order.created',
] as const

export const WebhookFormSchema = z.object({
  id: z.string(),
  url: z.string().url('Please enter a valid URL'),
  event: z.enum(WEBHOOK_EVENTS),
  enabled: z.boolean(),
})

export type WebhookFormValues = z.infer<typeof WebhookFormSchema>
export type WebhookEvent = (typeof WEBHOOK_EVENTS)[number]

// If you need a schema without ID for creation
export const WebhookSchemaWithoutId = WebhookFormSchema.omit({ id: true })
export type WebhookFormValuesWithoutId = z.infer<typeof WebhookSchemaWithoutId>

//

export const SettingsSchema = z.object({
  advanced: z.object({
    enableKyc: z.boolean().default(false),
    kycProvider: z.enum(KYC_PROVIDERS).default('manual'),
    enableLogs: z.boolean().default(true),
    logRetentionDays: z.coerce.number().int().min(1).max(365).default(30),
  }),
  auctions: z.object({
    defaultAbandonMinutes: z.coerce.number().int().min(5).max(240).default(45),
    softReservationHours: z.coerce.number().int().min(0).max(72).default(6),
    autoExpireAbandonedHours: z.coerce
      .number()
      .int()
      .min(1)
      .max(168)
      .default(24),
    bidIncrementStrategy: z.enum(BID_STRATEGIES).default('tiered'),
    bidIncrementValue: z.coerce.number().min(1).max(10_000).default(10),
    enableBuyNow: z.boolean().default(true),
    enableAutoBid: z.boolean().default(true),
    watchlistEnabled: z.boolean().default(true),
  }),
  general: z.object({
    siteName: z.string().min(2).max(100),
    currency: z.enum(CURRENCIES),
    timezone: z.string().min(2),
    dateFormat: z.string().min(4),
    allowGuestBrowsing: z.boolean(),
    maintenanceMode: z.boolean(),
  }),
  integrations: z.object({
    firebaseKey: z.string().optional().default(''),
    sendgridApiKey: z.string().optional().default(''),
    twilioAccountSid: z.string().optional().default(''),
    twilioAuthToken: z.string().optional().default(''),
    webhooks: z.array(WebhookFormSchema).default([]),
  }),
  notifications: z.object({
    emailFrom: z.string().email(),
    supportEmail: z.string().email(),
    smsFrom: z.string().optional().default(''),
    enableEmail: z.boolean(),
    enableSms: z.boolean(),
    enablePush: z.boolean(),
    outbidEmail: z.boolean(),
    endingSoonEmail: z.boolean(),
    cartAbandonedEmail: z.boolean(),
  }),
  payments: z.object({
    buyerPremiumPercent: z.coerce.number().min(0).max(100),
    taxPercent: z.coerce.number().min(0).max(100),
    allowInvoiceCheckout: z.boolean(),
    depositRequired: z.boolean(),
    depositAmount: z.coerce.number().min(0).max(1_000_000),
    supportedMethods: z.array(z.enum(PAYMENT_METHODS)).min(1),
  }),
})

export type SettingsFormValues = z.infer<typeof SettingsSchema>
