// /features/settings/route.tsx
import { createRoute } from '@tanstack/react-router'
import SettingsPage from './SettingsPage'
import { SettingsProvider } from './store'
import type { JSX } from 'react'
import type { RootRoute } from '@tanstack/react-router'

function SettingsRouteComponent(): JSX.Element {
  return (
    <SettingsProvider>
      <SettingsPage />
    </SettingsProvider>
  )
}

export default (parentRoute: RootRoute) =>
  createRoute({
    component: SettingsRouteComponent as unknown as (
      props: Record<string, never>,
    ) => JSX.Element,
    getParentRoute: () => parentRoute,
    path: '/settings',
  })
