// /features/settings/types.ts
export type Currency = 'EUR' | 'GBP' | 'USD'

export type BidIncrementStrategy = 'fixed' | 'tiered'

export type PaymentMethod = 'bank' | 'card' | 'paypal'

export type WebhookEvent = 'bid.placed' | 'cart.abandoned' | 'order.created'

export type Webhook = {
  id: string
  url: string
  event: WebhookEvent
  enabled: boolean
}

export type Settings = {
  advanced: {
    enableKyc: boolean
    kycProvider: 'manual' | 'persona' | 'sumsub'
    enableLogs: boolean
    logRetentionDays: number
  }
  auctions: {
    defaultAbandonMinutes: number
    softReservationHours: number
    autoExpireAbandonedHours: number
    bidIncrementStrategy: BidIncrementStrategy
    bidIncrementValue: number
    enableBuyNow: boolean
    enableAutoBid: boolean
    watchlistEnabled: boolean
  }
  general: {
    siteName: string
    currency: Currency
    timezone: string
    dateFormat: string
    allowGuestBrowsing: boolean
    maintenanceMode: boolean
  }
  integrations: {
    firebaseKey: string
    sendgridApiKey: string
    twilioAccountSid: string
    twilioAuthToken: string
    webhooks: Array<Webhook>
  }
  notifications: {
    emailFrom: string
    supportEmail: string
    smsFrom: string
    enableEmail: boolean
    enableSms: boolean
    enablePush: boolean
    outbidEmail: boolean
    endingSoonEmail: boolean
    cartAbandonedEmail: boolean
  }
  payments: {
    buyerPremiumPercent: number
    taxPercent: number
    allowInvoiceCheckout: boolean
    depositRequired: boolean
    depositAmount: number
    supportedMethods: Array<PaymentMethod>
  }
}
