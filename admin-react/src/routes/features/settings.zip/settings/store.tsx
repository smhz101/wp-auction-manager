// /features/settings/store.tsx
import { createContext, useContext, useEffect, useMemo, useState } from 'react'
import { DEFAULT_SETTINGS } from './defaults'
import type { JSX } from 'react'
import type { Settings } from './types'

const KEY = 'wpam.settings'

type SettingsState = {
  settings: Settings
}

type SettingsActions = {
  update: (next: Settings) => void
  reset: () => void
  importFromJson: (raw: string) => { ok: boolean; error?: string }
  exportToJson: () => string
  addWebhook: (w: Settings['integrations']['webhooks'][number]) => void
  updateWebhook: (w: Settings['integrations']['webhooks'][number]) => void
  deleteWebhook: (id: string) => void
}

const Ctx = createContext<{
  state: SettingsState
  actions: SettingsActions
} | null>(null)

export function SettingsProvider(props: {
  children: JSX.Element | Array<JSX.Element>
}): JSX.Element {
  const [settings, setSettings] = useState<Settings>(() => {
    try {
      const raw = localStorage.getItem(KEY)
      return raw ? (JSON.parse(raw) as Settings) : DEFAULT_SETTINGS
    } catch {
      return DEFAULT_SETTINGS
    }
  })

  useEffect(() => {
    try {
      localStorage.setItem(KEY, JSON.stringify(settings))
    } catch {}
  }, [settings])

  const actions: SettingsActions = useMemo(
    () => ({
      update: (next) => setSettings(next),
      reset: () => setSettings(DEFAULT_SETTINGS),
      importFromJson: (raw) => {
        try {
          const parsed = JSON.parse(raw) as Settings
          setSettings(parsed)
          return { ok: true }
        } catch (e: any) {
          return { ok: false, error: e?.message ?? 'Invalid JSON' }
        }
      },
      exportToJson: () => JSON.stringify(settings, null, 2),
      addWebhook: (w) =>
        setSettings((prev) => ({
          ...prev,
          integrations: {
            ...prev.integrations,
            webhooks: [w, ...prev.integrations.webhooks],
          },
        })),
      updateWebhook: (w) =>
        setSettings((prev) => ({
          ...prev,
          integrations: {
            ...prev.integrations,
            webhooks: prev.integrations.webhooks.map((x) =>
              x.id === w.id ? w : x,
            ),
          },
        })),
      deleteWebhook: (id) =>
        setSettings((prev) => ({
          ...prev,
          integrations: {
            ...prev.integrations,
            webhooks: prev.integrations.webhooks.filter((x) => x.id !== id),
          },
        })),
    }),
    [settings],
  )

  const value = { state: { settings }, actions }
  return <Ctx.Provider value={value}>{props.children}</Ctx.Provider>
}

export function useSettings(): {
  state: SettingsState
  actions: SettingsActions
} {
  const ctx = useContext(Ctx)
  if (!ctx) throw new Error('useSettings must be used within SettingsProvider')
  return ctx
}
