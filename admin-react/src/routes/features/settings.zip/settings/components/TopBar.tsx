// /features/settings/components/TopBar.tsx
import { useCallback, useState } from 'react'
import { useFormContext } from 'react-hook-form'
import { useSettings } from '../store'
import ImportExportDialog from './ImportExportDialog'
import type { JSX } from 'react'
import type { Settings } from '../types'
import type { SettingsFormValues } from '../schema'
import { Button } from '@/components/ui/button'

export default function TopBar(): JSX.Element {
  const form = useFormContext<SettingsFormValues>()
  const { actions } = useSettings()
  const [open, setOpen] = useBoolean(false)

  return (
    <div className="rounded-2xl border bg-white p-4 flex items-center gap-2">
      <Button variant="outline" onClick={() => setOpen(true)}>
        Import / Export
      </Button>
      <div className="ml-auto flex gap-2">
        <Button variant="outline" onClick={() => actions.reset()}>
          Reset to defaults
        </Button>
        <Button
          onClick={form.handleSubmit((values) =>
            actions.update(values as unknown as Settings),
          )}
        >
          Save changes
        </Button>
      </div>
      <ImportExportDialog open={open} onOpenChange={setOpen} />
    </div>
  )
}

function useBoolean(initial = false): [boolean, (v: boolean) => void] {
  const [v, setV] = useState<boolean>(initial)
  const set = useCallback((nv: boolean) => setV(nv), [])
  return [v, set]
}
