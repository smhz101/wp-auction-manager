// /features/settings/components/SectionNotifications.tsx
import { useFormContext } from 'react-hook-form'
import type { JSX } from 'react'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'

export default function SectionNotifications(): JSX.Element {
  return (
    <div className="rounded-2xl border bg-white p-5 space-y-4">
      <div className="grid gap-3 md:grid-cols-3">
        <Field label="Email from" name="notifications.emailFrom" />
        <Field label="Support email" name="notifications.supportEmail" />
        <Field label="SMS from" name="notifications.smsFrom" />
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Toggle label="Enable email" name="notifications.enableEmail" />
        <Toggle label="Enable SMS" name="notifications.enableSms" />
        <Toggle label="Enable push" name="notifications.enablePush" />
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Toggle label="Outbid email" name="notifications.outbidEmail" />
        <Toggle
          label="Ending soon email"
          name="notifications.endingSoonEmail"
        />
        <Toggle
          label="Cart abandoned email"
          name="notifications.cartAbandonedEmail"
        />
      </div>
    </div>
  )
}

function Field(props: { label: string; name: string }): JSX.Element {
  const form = useFormContext()
  return (
    <div className="grid gap-1">
      <Label>{props.label}</Label>
      <Input {...form.register(props.name as any)} />
    </div>
  )
}

function Toggle(props: { label: string; name: string }): JSX.Element {
  const form = useFormContext()
  const checked = form.getValues(props.name as any) as boolean
  return (
    <label className="flex items-center justify-between rounded-xl border p-3">
      <span>{props.label}</span>
      <Switch
        checked={checked}
        onCheckedChange={(v) => form.setValue(props.name as any, v)}
      />
    </label>
  )
}
