// /features/settings/components/SectionAdvanced.tsx
import { useFormContext } from 'react-hook-form'
import { KYC_PROVIDERS } from '../schema'
import type { JSX } from 'react'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Switch } from '@/components/ui/switch'

export default function SectionAdvanced(): JSX.Element {
  const form = useFormContext()

  return (
    <div className="rounded-2xl border bg-white p-5 space-y-4">
      <div className="grid gap-4 md:grid-cols-3">
        <Toggle label="Enable KYC" name="advanced.enableKyc" />
        <Toggle label="Enable logs" name="advanced.enableLogs" />
        <Num label="Log retention (days)" name="advanced.logRetentionDays" />
      </div>

      <div className="grid gap-1 md:w-72">
        <Label>KYC provider</Label>
        <Select
          value={form.getValues('advanced.kycProvider')}
          onValueChange={(v) => form.setValue('advanced.kycProvider', v)}
        >
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {KYC_PROVIDERS.map((p) => (
              <SelectItem key={p} value={p}>
                {p}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
    </div>
  )
}

function Toggle(props: { label: string; name: string }): JSX.Element {
  const form = useFormContext()
  const checked = form.getValues(props.name as any) as boolean
  return (
    <label className="flex items-center justify-between rounded-xl border p-3">
      <span>{props.label}</span>
      <Switch
        checked={checked}
        onCheckedChange={(v) => form.setValue(props.name as any, v)}
      />
    </label>
  )
}

function Num(props: { label: string; name: string }): JSX.Element {
  const form = useFormContext()
  return (
    <div className="grid gap-1">
      <Label>{props.label}</Label>
      <Input
        type="number"
        {...form.register(props.name as any, { valueAsNumber: true })}
      />
    </div>
  )
}
