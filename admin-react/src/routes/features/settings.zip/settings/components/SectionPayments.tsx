// /features/settings/components/SectionPayments.tsx
import { useFormContext } from 'react-hook-form'
import { PAYMENT_METHODS } from '../schema'
import type { PaymentMethod } from '../types'
import type { JSX } from 'react'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'

export default function SectionPayments(): JSX.Element {
  const form = useFormContext()
  const methods = form.getValues(
    'payments.supportedMethods',
  ) as Array<PaymentMethod>

  function toggleMethod(m: PaymentMethod): void {
    const set = new Set<PaymentMethod>(methods)
    set.has(m) ? set.delete(m) : set.add(m)
    form.setValue('payments.supportedMethods', Array.from(set))
  }

  return (
    <div className="rounded-2xl border bg-white p-5 space-y-4">
      <div className="grid gap-3 md:grid-cols-3">
        <Num label="Buyer premium %" name="payments.buyerPremiumPercent" />
        <Num label="Tax %" name="payments.taxPercent" />
      </div>

      <div className="grid gap-3 md:grid-cols-3">
        <Toggle label="Invoice checkout" name="payments.allowInvoiceCheckout" />
        <Toggle label="Deposit required" name="payments.depositRequired" />
        <Num label="Deposit amount" name="payments.depositAmount" />
      </div>

      <div className="grid gap-1">
        <Label>Supported methods</Label>
        <div className="flex flex-wrap gap-2">
          {PAYMENT_METHODS.map((m) => {
            const on = methods.includes(m)
            return (
              <Badge
                key={m}
                variant={on ? 'default' : 'secondary'}
                className="cursor-pointer"
                onClick={() => toggleMethod(m)}
              >
                {m}
              </Badge>
            )
          })}
        </div>
      </div>
    </div>
  )
}

function Num(props: { label: string; name: string }): JSX.Element {
  const form = useFormContext()
  return (
    <div className="grid gap-1">
      <Label>{props.label}</Label>
      <Input
        type="number"
        step="0.01"
        {...form.register(props.name as any, { valueAsNumber: true })}
      />
    </div>
  )
}

function Toggle(props: { label: string; name: string }): JSX.Element {
  const form = useFormContext()
  const checked = form.getValues(props.name as any) as boolean
  return (
    <label className="flex items-center justify-between rounded-xl border p-3">
      <span>{props.label}</span>
      <Switch
        checked={checked}
        onCheckedChange={(v) => form.setValue(props.name as any, v)}
      />
    </label>
  )
}
