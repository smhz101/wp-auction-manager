// /features/settings/components/WebhookDialog.tsx
import { zodResolver } from '@hookform/resolvers/zod'
import { useForm } from 'react-hook-form'
import { WEBHOOK_EVENTS, WebhookSchemaWithoutId } from '../schema'

import type { JSX } from 'react'
import type { SubmitHandler } from 'react-hook-form'
import type { WebhookFormValues, WebhookFormValuesWithoutId } from '../schema'

import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'

interface WebhookDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onCreate: (webhook: WebhookFormValues) => void
}

export default function WebhookDialog({
  open,
  onOpenChange,
  onCreate,
}: WebhookDialogProps): JSX.Element {
  const form = useForm<WebhookFormValuesWithoutId>({
    resolver: zodResolver(WebhookSchemaWithoutId),
    defaultValues: {
      url: '',
      event: 'order.created',
      enabled: true,
    },
    mode: 'onChange',
  })

  const onSubmit: SubmitHandler<WebhookFormValuesWithoutId> = (values) => {
    const id = `wh_${Math.random().toString(36).slice(2, 9)}`
    onCreate({ ...values, id })
    onOpenChange(false)
    form.reset()
  }

  const handleCancel = () => {
    onOpenChange(false)
    form.reset()
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[520px]">
        <DialogHeader>
          <DialogTitle>Add webhook</DialogTitle>
          <DialogDescription>
            Send POST requests on specific plugin events.
          </DialogDescription>
        </DialogHeader>

        <form className="grid gap-3" onSubmit={form.handleSubmit(onSubmit)}>
          <div className="grid gap-1">
            <Label>URL</Label>
            <Input {...form.register('url')} />
            {form.formState.errors.url && (
              <p className="text-xs text-red-600">
                {form.formState.errors.url.message}
              </p>
            )}
          </div>

          <div className="grid gap-1">
            <Label>Event</Label>
            <Select
              value={form.getValues('event')}
              onValueChange={(v) =>
                form.setValue('event', v as WebhookFormValues['event'], {
                  shouldValidate: true,
                })
              }
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {WEBHOOK_EVENTS.map((e) => (
                  <SelectItem key={e} value={e}>
                    {e}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={handleCancel}>
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={!form.formState.isValid || form.formState.isSubmitting}
            >
              {form.formState.isSubmitting ? 'Adding...' : 'Add Webhook'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
