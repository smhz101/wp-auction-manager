// /features/settings/components/SectionGeneral.tsx
import { useFormContext } from 'react-hook-form'
import { CURRENCIES } from '../schema'
import type { JSX } from 'react'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Switch } from '@/components/ui/switch'

export default function SectionGeneral(): JSX.Element {
  const form = useFormContext()

  return (
    <div className="rounded-2xl border bg-white p-5 space-y-4">
      <div className="grid gap-3 md:grid-cols-2">
        <div className="grid gap-1">
          <Label htmlFor="siteName">Site name</Label>
          <Input id="siteName" {...form.register('general.siteName')} />
        </div>

        <div className="grid gap-1">
          <Label>Currency</Label>
          <Select
            value={form.getValues('general.currency')}
            onValueChange={(v) => form.setValue('general.currency', v)}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {CURRENCIES.map((c) => (
                <SelectItem key={c} value={c}>
                  {c}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="grid gap-1">
          <Label htmlFor="timezone">Timezone</Label>
          <Input
            id="timezone"
            placeholder="e.g. Europe/London"
            {...form.register('general.timezone')}
          />
        </div>

        <div className="grid gap-1">
          <Label htmlFor="dateFormat">Date format</Label>
          <Input
            id="dateFormat"
            placeholder="dd/MM/yyyy"
            {...form.register('general.dateFormat')}
          />
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <ToggleField
          checked={form.getValues('general.allowGuestBrowsing')}
          label="Allow guest browsing"
          onChange={(v) => form.setValue('general.allowGuestBrowsing', v)}
        />
        <ToggleField
          checked={form.getValues('general.maintenanceMode')}
          label="Maintenance mode"
          onChange={(v) => form.setValue('general.maintenanceMode', v)}
        />
      </div>
    </div>
  )
}

function ToggleField(props: {
  label: string
  checked: boolean
  onChange: (v: boolean) => void
}): JSX.Element {
  return (
    <label className="flex items-center justify-between rounded-xl border p-3">
      <span>{props.label}</span>
      <Switch checked={props.checked} onCheckedChange={props.onChange} />
    </label>
  )
}
