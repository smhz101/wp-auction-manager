// /features/settings/components/SectionIntegrations.tsx
import { useCallback, useState } from 'react'
import { useFormContext } from 'react-hook-form'
import { useSettings } from '../store'
import WebhookDialog from './WebhookDialog'
import type { JSX } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'

export default function SectionIntegrations(): JSX.Element {
  const {
    state: { settings },
    actions,
  } = useSettings()
  const [open, setOpen] = useBoolean(false)
  const [confirmDelete, setConfirmDelete] = useBoolean(false)
  const [toDelete, setToDelete] = useStateSafe<string>('')

  return (
    <div className="rounded-2xl border bg-white p-5 space-y-6">
      <div className="grid gap-3 md:grid-cols-2">
        <Field label="SendGrid API key" name="integrations.sendgridApiKey" />
        <Field label="Firebase key" name="integrations.firebaseKey" />
        <Field
          label="Twilio Account SID"
          name="integrations.twilioAccountSid"
        />
        <Field label="Twilio Auth Token" name="integrations.twilioAuthToken" />
      </div>

      <div>
        <div className="mb-2 flex items-center justify-between">
          <div className="font-medium">Webhooks</div>
          <Button variant="outline" onClick={() => setOpen(true)}>
            Add webhook
          </Button>
        </div>

        <div className="overflow-x-auto rounded-xl border">
          <table className="min-w-full text-sm">
            <thead className="text-left text-zinc-600">
              <tr>
                <th className="px-3 py-2">Event</th>
                <th className="px-3 py-2">URL</th>
                <th className="px-3 py-2">Enabled</th>
                <th className="px-3 py-2"></th>
              </tr>
            </thead>
            <tbody>
              {settings.integrations.webhooks.map((w) => (
                <tr key={w.id} className="border-t">
                  <td className="px-3 py-2">{w.event}</td>
                  <td className="px-3 py-2">{w.url}</td>
                  <td className="px-3 py-2">
                    <Switch
                      checked={w.enabled}
                      onCheckedChange={(v) =>
                        actions.updateWebhook({ ...w, enabled: v })
                      }
                    />
                  </td>
                  <td className="px-3 py-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() =>
                        actions.updateWebhook({ ...w, enabled: !w.enabled })
                      }
                    >
                      Toggle
                    </Button>
                    <Button
                      variant="destructive"
                      size="sm"
                      className="ml-2"
                      onClick={() => {
                        setToDelete(w.id)
                        setConfirmDelete(true)
                      }}
                    >
                      Delete
                    </Button>
                  </td>
                </tr>
              ))}
              {settings.integrations.webhooks.length === 0 && (
                <tr>
                  <td
                    className="px-3 py-8 text-center text-zinc-500"
                    colSpan={4}
                  >
                    No webhooks yet.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      <WebhookDialog
        open={open}
        onOpenChange={setOpen}
        onCreate={(w) => actions.addWebhook(w)}
      />

      <AlertDialog open={confirmDelete} onOpenChange={setConfirmDelete}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete webhook?</AlertDialogTitle>
            <AlertDialogDescription>
              This cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-red-600 hover:bg-red-700"
              onClick={() => {
                actions.deleteWebhook(toDelete)
                setConfirmDelete(false)
              }}
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}

function Field(props: { label: string; name: string }): JSX.Element {
  const form = useFormContext()
  return (
    <div className="grid gap-1">
      <Label>{props.label}</Label>
      <Input {...form.register(props.name as any)} />
    </div>
  )
}

function useStateSafe<T>(initial: T): [T, (v: T) => void] {
  const [v, setV] = useState<T>(initial)
  const set = useCallback((nv: T) => setV(nv), [])
  return [v, set]
}
function useBoolean(initial = false): [boolean, (v: boolean) => void] {
  const [v, setV] = useState<boolean>(initial)
  const set = useCallback((nv: boolean) => setV(nv), [])
  return [v, set]
}
