// /features/settings/components/SectionAuctions.tsx
import { useFormContext } from 'react-hook-form'
import { BID_STRATEGIES } from '../schema'
import type { JSX } from 'react'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Switch } from '@/components/ui/switch'

export default function SectionAuctions(): JSX.Element {
  const form = useFormContext()

  return (
    <div className="rounded-2xl border bg-white p-5 space-y-4">
      <div className="grid gap-3 md:grid-cols-3">
        <Num
          label="Abandon after (min)"
          name="auctions.defaultAbandonMinutes"
        />
        <Num
          label="Reservation hold (h)"
          name="auctions.softReservationHours"
        />
        <Num
          label="Auto-expire abandoned (h)"
          name="auctions.autoExpireAbandonedHours"
        />
      </div>

      <div className="grid gap-3 md:grid-cols-3">
        <div className="grid gap-1">
          <Label>Bid increment strategy</Label>
          <Select
            value={form.getValues('auctions.bidIncrementStrategy')}
            onValueChange={(v) =>
              form.setValue('auctions.bidIncrementStrategy', v)
            }
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {BID_STRATEGIES.map((s) => (
                <SelectItem key={s} value={s}>
                  {s}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <Num label="Increment value" name="auctions.bidIncrementValue" />
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Toggle label="Enable Buy Now" name="auctions.enableBuyNow" />
        <Toggle label="Enable Auto-bid" name="auctions.enableAutoBid" />
        <Toggle label="Watchlist enabled" name="auctions.watchlistEnabled" />
      </div>
    </div>
  )
}

function Num(props: { label: string; name: string }): JSX.Element {
  const form = useFormContext()
  return (
    <div className="grid gap-1">
      <Label>{props.label}</Label>
      <Input
        type="number"
        {...form.register(props.name as any, { valueAsNumber: true })}
      />
    </div>
  )
}

function Toggle(props: { label: string; name: string }): JSX.Element {
  const form = useFormContext()
  const checked = form.getValues(props.name as any) as boolean
  return (
    <label className="flex items-center justify-between rounded-xl border p-3">
      <span>{props.label}</span>
      <Switch
        checked={checked}
        onCheckedChange={(v) => form.setValue(props.name as any, v)}
      />
    </label>
  )
}
