// /features/settings/components/ImportExportDialog.tsx
import { useCallback, useState } from 'react'
import { useSettings } from '../store'
import type { JSX } from 'react'
import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Textarea } from '@/components/ui/textarea'

export default function ImportExportDialog(props: {
  open: boolean
  onOpenChange: (v: boolean) => void
}): JSX.Element {
  const { open, onOpenChange } = props
  const { actions } = useSettings()
  const [tab, setTab] = useStateSafe<'import' | 'export'>('import')
  const [text, setText] = useStateSafe('')

  function onExport(): void {
    setText(actions.exportToJson())
    setTab('export')
  }

  function onImport(): void {
    const { ok, error } = actions.importFromJson(text)
    if (!ok)
      alert(error ?? 'Invalid JSON') // replace with shadcn toast if you prefer
    else onOpenChange(false)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[680px]">
        <DialogHeader>
          <DialogTitle>Import / Export Settings</DialogTitle>
          <DialogDescription>
            Copy JSON to export, or paste JSON to import.
          </DialogDescription>
        </DialogHeader>

        <Tabs value={tab} onValueChange={(v) => setTab(v as typeof tab)}>
          <TabsList>
            <TabsTrigger value="import">Import</TabsTrigger>
            <TabsTrigger value="export" onClick={onExport}>
              Export
            </TabsTrigger>
          </TabsList>

          <TabsContent value="import">
            <Textarea
              rows={14}
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="{ ...settings json... }"
            />
            <DialogFooter className="mt-3">
              <Button variant="outline" onClick={() => onOpenChange(false)}>
                Cancel
              </Button>
              <Button onClick={onImport}>Import</Button>
            </DialogFooter>
          </TabsContent>

          <TabsContent value="export">
            <Textarea rows={14} value={text} readOnly />
            <DialogFooter className="mt-3">
              <Button onClick={() => navigator.clipboard.writeText(text)}>
                Copy
              </Button>
            </DialogFooter>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  )
}

function useStateSafe<T>(initial: T): [T, (v: T) => void] {
  const [v, setV] = useState<T>(initial)
  const set = useCallback((nv: T) => setV(nv), [])
  return [v, set]
}
