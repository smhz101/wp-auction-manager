// /features/settings/components/Sidebar.tsx
import type { JSX } from 'react'
import { Button } from '@/components/ui/button'
import { ScrollArea } from '@/components/ui/scroll-area'

const SECTIONS = [
  { id: 'general', label: 'General' },
  { id: 'auctions', label: 'Auctions' },
  { id: 'payments', label: 'Payments' },
  { id: 'notifications', label: 'Notifications' },
  { id: 'integrations', label: 'Integrations' },
  { id: 'advanced', label: 'Advanced' },
] as const

export type SectionId = (typeof SECTIONS)[number]['id']

export default function Sidebar(props: {
  current: SectionId
  onSelect: (id: SectionId) => void
}): JSX.Element {
  const { current, onSelect } = props

  return (
    <div className="rounded-2xl border bg-white">
      <div className="border-b p-3 text-sm text-zinc-600">Settings</div>
      <ScrollArea className="max-h-[78vh]">
        <div className="p-2 space-y-1">
          {SECTIONS.map((s) => (
            <Button
              key={s.id}
              variant={current === s.id ? 'default' : 'ghost'}
              className="w-full justify-start"
              onClick={() => onSelect(s.id)}
            >
              {s.label}
            </Button>
          ))}
        </div>
      </ScrollArea>
    </div>
  )
}
