// /features/settings/SettingsPage.tsx
import { useState } from 'react'
import { zodResolver } from '@hookform/resolvers/zod'
import { FormProvider, useForm } from 'react-hook-form'
import SectionAdvanced from './components/SectionAdvanced'
import SectionAuctions from './components/SectionAuctions'
import SectionGeneral from './components/SectionGeneral'
import SectionIntegrations from './components/SectionIntegrations'
import SectionNotifications from './components/SectionNotifications'
import SectionPayments from './components/SectionPayments'
import Sidebar from './components/Sidebar'
import TopBar from './components/TopBar'
import { SettingsSchema } from './schema'
import { useSettings } from './store'
import type { JSX } from 'react'
import type { SectionId } from './components/Sidebar'
import type { SettingsFormValues } from './schema'
import type { Resolver } from 'react-hook-form'

export default function SettingsPage(): JSX.Element {
  const {
    state: { settings },
  } = useSettings()
  const form = useForm<SettingsFormValues>({
    defaultValues: settings,
    // resolver: zodResolver(SettingsSchema),
    resolver: zodResolver(
      SettingsSchema,
    ) as unknown as Resolver<SettingsFormValues>,
    mode: 'onChange',
  })

  const [section, setSection] = useState<SectionId>('general')

  return (
    <div className="p-6">
      {/* Header */}
      <h1 className="text-2xl font-bold mb-6">Settings</h1>

      {/* Body */}
      <section className="py-6">
        <FormProvider {...form}>
          <div className="grid gap-6 lg:grid-cols-[300px_1fr]">
            <Sidebar current={section} onSelect={setSection} />

            <div className="space-y-4">
              <TopBar />

              {section === 'general' && <SectionGeneral />}
              {section === 'auctions' && <SectionAuctions />}
              {section === 'payments' && <SectionPayments />}
              {section === 'notifications' && <SectionNotifications />}
              {section === 'integrations' && <SectionIntegrations />}
              {section === 'advanced' && <SectionAdvanced />}
            </div>
          </div>
        </FormProvider>
      </section>
    </div>
  )
}
