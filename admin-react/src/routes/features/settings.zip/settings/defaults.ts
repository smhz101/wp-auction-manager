// /features/settings/defaults.ts
import type { Settings } from './types'

export const DEFAULT_SETTINGS: Settings = {
  advanced: {
    enableKyc: true,
    kycProvider: 'manual',
    enableLogs: true,
    logRetentionDays: 30,
  },
  auctions: {
    defaultAbandonMinutes: 45,
    softReservationHours: 6,
    autoExpireAbandonedHours: 24,
    bidIncrementStrategy: 'tiered',
    bidIncrementValue: 10,
    enableBuyNow: true,
    enableAutoBid: true,
    watchlistEnabled: true,
  },
  general: {
    siteName: 'WP Auction Marketplace',
    currency: 'GBP',
    timezone: 'Europe/London',
    dateFormat: 'dd/MM/yyyy',
    allowGuestBrowsing: true,
    maintenanceMode: false,
  },
  integrations: {
    firebaseKey: '',
    sendgridApiKey: '',
    twilioAccountSid: '',
    twilioAuthToken: '',
    webhooks: [],
  },
  notifications: {
    emailFrom: 'noreply@example.com',
    supportEmail: 'support@example.com',
    smsFrom: '',
    enableEmail: true,
    enableSms: false,
    enablePush: false,
    outbidEmail: true,
    endingSoonEmail: true,
    cartAbandonedEmail: true,
  },
  payments: {
    buyerPremiumPercent: 15,
    taxPercent: 0,
    allowInvoiceCheckout: false,
    depositRequired: false,
    depositAmount: 0,
    supportedMethods: ['card', 'bank'],
  },
}
